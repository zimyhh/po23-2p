function NewBlock() {
    const registration = document.getElementById("registration");
    
    const block = document.createElement("div");
    block.classList.add("box");

    const title = document.createElement("h2");
    title.classList.add("text-reg");
    title.innerText = "Регистрация и Вход";
    block.appendChild(title);
    
    const controls = document.createElement("div");
    controls.classList.add("controls");
    
    const textlogin = document.createElement("input");
    textlogin.type = "text";
    textlogin.placeholder = "Login";
    textlogin.classList.add("input-field");
    
    const textpassword = document.createElement("input");
    textpassword.type = "password";
    textpassword.placeholder = "Password";
    textpassword.classList.add("input-field");

    const LogButton = document.createElement("button");
    LogButton.type = "button";
    LogButton.classList.add("button-1");
    LogButton.innerText = "Войти";

    controls.appendChild(textlogin);
    controls.appendChild(textpassword);
    controls.appendChild(LogButton);

    block.appendChild(controls);
    registration.appendChild(block);
}